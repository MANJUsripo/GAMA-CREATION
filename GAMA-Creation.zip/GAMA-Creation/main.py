import numpy as np
import cv2
from cvzone.HandTrackingModule import HandDetector
import google.generativeai as genai
from PIL import Image
import streamlit as st
st.set_page_config(layout='wide')
st.title("math problem  ✨")
st.write("GAMA CREATION")
column1,column2=st.columns([2,1])
with column1:
    
     frameWindow=st.image([])
with column2:
     st.title("Answer")   
     outputText=st.subheader("")

genai.configure(api_key="AIzaSyAv68o-reLBgb6_PejzR_kX1NCV7vSZW3o")
model = genai.GenerativeModel('gemini-1.5-flash')

cap = cv2.VideoCapture(0)
cap.set(3,1280)
cap.set(4,720)

detector = HandDetector(staticMode=False, maxHands=1, modelComplexity=1, detectionCon=0.7, minTrackCon=0.5)

def getHandInfo(img):
    
    hands, img = detector.findHands(img, draw=False, flipType=True)

        
    if hands:

        hand1 = hands[0]  
    
        lmList = hand1["lmList"]  
        fingers = detector.fingersUp(hand1)
        return fingers,lmList
    else:
        return None

def draw(info,previousPosition,canvas):
    fingers, lmlist=info
    currentPosition=None
    if fingers==[0,1,0,0,0]:
          currentPosition=lmlist[8][0:2]
          if previousPosition is None: 
               previousPosition=currentPosition
          cv2.line(canvas,currentPosition,previousPosition,(255,0,255),10)
    elif fingers==[1,1,1,1,1]:
         
         canvas= np.zeros_like(img)     
    return currentPosition,canvas

def sendToGemeni(model,canvas,fingers):
    if fingers==[1,1,1,1,0]:
        Pil_image=Image.fromarray(canvas)
        response = model.generate_content(["solve this math problem",Pil_image])
        return response.text
previousPosition=None
canvas=None
combinedImage=None
outputResult=""
while True:
        
        success, img = cap.read()
        img=cv2.flip(img,1)
        if canvas is None:
            canvas=np.zeros_like(img)
            combinedImage=img.copy
        info=getHandInfo(img)
        if info:
            fingers,lmlist=info
            
            previousPosition,canvas=draw(info,previousPosition,canvas)
            outputResult=sendToGemeni(model,canvas,fingers)
        combinedImage=cv2.addWeighted(img,0.7,canvas,0.3,0)
              
        
        frameWindow.image(combinedImage,channels="BGR")
        if(outputResult):
            outputText.text(outputResult)

        if cv2.waitKey(1)==ord('q'):
             break
cv2.destroyAllWindows()        

